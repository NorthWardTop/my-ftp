#iceftpd
小型的ftp服务器，运行平台为Linux。  
如果运行不成功，查看/etc/hosts(Ubuntu为/etc/hostname)文件的信息，看主机名对应的ip地址对不对，如果不对，修改为自己主机的ip就行了。