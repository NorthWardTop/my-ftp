#ifndef _PARSE_CONF_H_
#define _PARSE_CONF_H_

void parseconf_load_file(const char *path);
void parseconf_load_setting(const char *setting);

#endif /* _PARSE_CONF_H_ */

